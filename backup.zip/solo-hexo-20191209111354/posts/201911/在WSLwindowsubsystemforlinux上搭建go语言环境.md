title: 在WSL(window subsystem for linux)上搭建go语言环境
date: '2019-11-27 16:06:31'
updated: '2019-11-28 15:12:00'
tags: [环境搭建]
permalink: /articles/2019/11/27/1574841991080.html
---
首先到micsoft store上去下载ubuntu的
下载后设置账户密码即可
****

1. 1:
配置共享的目录:
为了方便在window和wsl之间拷贝文件,首先设置共享的目录 ,在windows上创建一个UbuntuShare文件,在WSL添加软连接:
```
ln -s /mnt/c/Users/自己电脑的用户名/UbuntuShare/ win10
```
1. 2:
WSL安装GO:
从该网址:https://studygolang.com/dl 中下载linux go的安装包 放到之前的那个共享的目录,就可以可以在WSL中操作下载的安装包:
```
cd win10
sudo tar -xzf go1.12.5.linux-amd64.tar.gz -C /usr/local/
1. 3:
将window和linux的GOPATH设置为同一路径,就可以在window10和ubuntu中公用一套第三方包

执行以下命令
```
vim /etc/profile
//在文件末尾添加以下内容:

export GOROOT=/urs/local/go

export GOBIN=$GOROOT/bin

export GOPKG=$GOROOT/pkg/tool/linux_amd64

export GOARCH=amd64

export GOOS=linux

export GOPATH=/mnt/自己电脑window系统中的GOPATH路径

export PATH=$PATH:$GOBIN:$GOPKG:$GOPATH/bin

```
1. 4:
执行和测试
```
source /etc/profile
go version
go env
```
如果看到以下内容:
![image.png](https://img.hacpai.com/file/2019/11/image-87666491.png)

![image.png](https://img.hacpai.com/file/2019/11/image-7a05f4db.png)

即打印出了golang的版本信息 即为安装成功

