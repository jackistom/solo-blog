title: (史上最好用!!!!!!!!!!!!!!!!!!!!!!!!!!)关于树莓派上python3的opencv的环境搭建
date: '2019-12-06 11:50:18'
updated: '2019-12-06 13:17:41'
tags: [环境搭建, python-opencv, 树莓派]
permalink: /articles/2019/12/06/1575604218543.html
---
**前言:**      2019/12/6  11:45 刚刚又帮实验室同学配置了一下opencv(python3)的环境,虽然已经配置过N遍了,但是一些细节上的步骤记不清楚.csdn上关于此的blog大多是垃圾,只不过是seo做的好罢了.用树莓派和python-opencv做图像识别还是比较常见和基础的,既然会经常用到,又没有一篇好的blog,所以我决定自己花点时间记录一下.保证看这一篇就够了!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



环境:raspberrypi3B+ ,镜像是 debian 9 (stretch)版本,python3.5
下面我们要安装的opencv的版本是3.4.4.19的
![image.png](https://img.hacpai.com/file/2019/12/image-6e31a584.png)
cp35的意思是对应的是python3.5的版本 ,下载时,自己注意一下,版本的对应

1. 1:
这篇blog是默认已经安装好了系统
1. 2:
首先 没有换源的小伙伴记得换源 ::
![image.png](https://img.hacpai.com/file/2019/12/image-ed41ab96.png)

跟着图中的执行步骤 操作就行了 这里我的版本是debian 9 (stretch) 注意一下版本
如果版本不一样 :自己访问一下以下网址,选一下自己使用的版本镜像.
https://mirrors.tuna.tsinghua.edu.cn/help/raspbian/


换好源后,
```
sudo apt-get install update //更新一下,没有必要upgrade 
```
对了 ,记得联网啊 (提醒一下刚刚开始玩树莓派的小伙伴)
1. 3:
**重点来了!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!**
*网上什么源代码编制安装的方式啊还有什么乱七八糟的骚操作,根本没有,(我已经猜过大部分的坑,整个安装过程),如果你直接 sudo apt-get install opencv 或是 python-opencv之类的话 一般都是报错(找不到该库,顶多安装上python2对应的opencv的版本)*
所以我们这里通过适用于arm的whl文件来安装,我安装使用的文件很小,才7MB,我给出的百度云分享中有两个版本,任何一个都行:
链接：https://pan.baidu.com/s/1bsIE5UNfpsn2jy53gyGuAg 
提取码：k6os
(这里使用的轮子文件,是对应的python3.5的版本,比较通用,注意下版本的对应哦,如果用的python3不是3.5的可以卸载了,重新install一下,安装python很简单的)


cp对应你的python的版本 cp35 就是对应python3.5,

这个文件我们需要把它放到树莓派的/home/pi目录下,可以先把sd卡拔掉,在电脑上下完该文件后,复制到sd中,然后再插上去,因为镜像是linux系统,所以插到window读不不出来,还让你格式化,千万别格式化!!!!!!!!!!!!!!!!!!!!!!你可以看到此时你的电脑里面多了一个boot分区,只有几个MB,把刚刚下肢的文件放进去.然后插上树莓派 重新开始.

1. 4:
此时我们下载的文件放在/boot目录下 所以我们要把它弄到/home/pi目录下 ,直接在窗口里面复制是不行的.会提示你权限不够.所以 你需要在命令行中操作:
```
sudo cp -r /boot/文件名 /home/pi/  //复制文件
cd ~//cd到用户目录
sudo rm -rf 文件名 //删掉/boot路径下的文件
```
1. 5:
然后,我们进行下一步
安装opencv要用到的其他依赖包
直接全部执行下面操作就行了:
```
sudo apt-get update
sudo apt-get install libjpeg-dev
sudo apt-get install libatlas-base-dev
sudo apt-get install libtiff5-dev
sudo apt-get install libpng12-dev
sudo apt-get install libjasper-dev
sudo apt-get install libgstreamer1.0-0
sudo apt-get install libgstreamer-plugins-base1.0-0
sudo apt-get install libqtgui4  libqt4-test
```
ok,下完后我们接着就安装opencv了:
```
sudo pip3 install 文件名 //文件名太长,按tap键就行了(可能有些小伙伴对linux不太熟悉)
```

最后显示:

![image.png](https://img.hacpai.com/file/2019/12/image-4776f6c9.png)
即为安装成功

最后测试一下:

```
python3

import cv2

```
如果如下图所示就是可以用啦!!!!!!!!!!!!!!!!!!!!


![image.png](https://img.hacpai.com/file/2019/12/image-d6a47fde.png)


CUE:
可能在安装中会遇到以下问题:
![image.png](https://img.hacpai.com/file/2019/12/image-0ab0095d.png)

解决方案是:
```
jobs -l //查看后天挂起的程序 每一个程序前面有一个四个数值的ID

sudo kill -9 -ID //删除挂起程序就行了


```
![image.png](https://img.hacpai.com/file/2019/12/image-203a7990.png)









![image.png](https://img.hacpai.com/file/2019/12/image-02ca167e.png)

