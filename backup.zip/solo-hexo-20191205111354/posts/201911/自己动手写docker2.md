title: 自己动手写docker_2
date: '2019-11-27 15:35:11'
updated: '2019-11-28 17:40:07'
tags: [book, docker]
permalink: /articles/2019/11/27/1574840111490.html
---
![](https://img.hacpai.com/bing/20190208.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

**基础技术**
1. 1
**Linux Namespace 介绍:**
我们经常听到， Docker 是一个使用了 Linux Namespace 和 Cgroups 的虚拟化工具。 但是，
什么是 Linux Namespace，它在 Docker 内是怎么被使用的？说到这里，很多人就会迷茫。下面
就先来介绍一下 Linux Namespace 及它们是如何在容器中使用的.
1. 2
**概念:**
Linux Namespace 是 Kernel 的一个功能，它可以隔离一系列的系统资源，比如 PIO ( Process ID）、 User ID、 Network 等。 一般看到这里，很多人会想到一个命令 chroot，就像 chroot 允许
把当前目录变成根目录一样（被隔离开来的） , Namespace 也可以在一些资源上，将进程隔离
起来，这些资源包括进程树、网络接口、挂载点等。 使用 Namespace，就可以做到 urn 级别的隔离，也就是说，可以以 urn 为 n 的用户，虚拟化出来一个 Namespace， 在这个 Namespace 里面，用户是具有 root 权限的。但是，在真实 的物理机器上，他还是那个以 urn 为 n 的用户，这样就解决了用户之间隔离的问题。
除了user Namespace外, PID也是可以被虚拟的:![image.png](https://img.hacpai.com/file/2019/11/image-d8074067.png)
**命名空间建立系统的不同视图，从用户的 角度来看，每一个命名空间应该像一台单独的 Linux 计算机一样，有自己的 init 进程 CPID 为 I ），其他进程的 PID 依次递增， A 和 B 空间都有 PID 为 l 的 init 进程， 子命名空间的进程映 射到父命名空间的进程上，父命名空间可以知道每一个子命名空间的运行状态，而子命名空间 与子命名空间之间是隔离的。 从图 2.1 所示的 PID 映射关系图中可以看到，进程 3 在父命名空 间中的 PID 为 3，但是在子命名空间内，它的 PID 就是 1 。也就是说用户从子命名空间 A 内看 进程 3 就像 init 进程一样，以为这个进程是自己的初始化进程，但是从整个 host 来看，它其实 只是 3 号进程虚拟化出来的一个空间而己。**
当前的linux一共实现的6种不同类型的Namespace:
![image.png](https://img.hacpai.com/file/2019/11/image-bdc8b6cb.png)

Namespace 的 API 主要使用如下 3 个系统调用 👍 : 
 clone（）:创建新进程。根据系统调用参数来判断哪些类型的 Namespace 被创建，而且它们 的子进程也会被包含到这些 Namespace 中。 。
 unshare（）:将进程移出某个 Namespaceo 。 
setns（）:将进程加入到 Namespace 中

**每一个类型的Namespace实际上都起到了在某个功能上与主进程之间的隔离,他们通过对不同功能的隔离最后是实现了一个容器!**

1. 3.1
**UTS Namespace**
UTS Namesapce 主要是用来隔离nodename和domainname两个系统标识.在UTS Namespace里面,每个Namespace允许有自己的hostname,主要用来隔离主机和域名.



1. 3.2:
**IPC Namescape** 进程间通信:IPC(InterProcess Communication）**是指在不同进程之间传播或交换信息。IPC的方式通常有管道（包括无名管道和命名管道）、消息队列、信号量、共享存储、Socket、Streams等。其中 Socket和Streams支持不同主机上的两个进程IPC。**
IPC Namespace 用来隔离 System V IPC 和 POSIX message queues。 每一个 IPC Namespace 都有自己的 System V IPC 和 POSIX message queue。


1. 3.3:
**PID Namescape**
PID Namespace 是用来隔离进程 ID 的。同样一个进程在不同的 PID Namespace 里可以拥 有不同的 PID。这样就可以理解， 在 docker container 里面， 使用 ps -ef经常会发现， 在容器 内 ， 前台运行的那个进程 PID 是 l ， 但是在容器外，使用 ps -ef会发现同样的进程却有不同的PID， 这就是 PID Namespace 做的事情。

1. 3.4:
**Mount Namespace**
Mount Namespace 用来隔离各个进程看到的挂载点视图。在不同 Namespace 的进程中 ， 看 到的文件系统层次是不一样的。在 Mount Namespace 中调用 mount（）和 umount（） 仅仅只会影响 当前 Namespace 内的文件系统，而对全局的文件系统是没有影响的。 
Mount Namespace 是 Linux 第 一个实现 的 Namespace 类型.
1. 3.5:
**User Namespace**
User N amespace 主要是隔离用户 的用户组 ID。 也就是说， 一个进程的 User ID 和 Group ID 在 User Namespace 内外可以是不同的。 比较常用 的是，在宿主机上以一个非 root 用户运行
创建一个 User Namespace， 然后在 User Namespace 里面却映射成 root 用户。这意味着， 这个
进程在 User Namespace 里面有 root 权限，但是在 User Namespace 外面却没有 root 的权限。从 Linux Kernel 3.8 开始， 非 root 进程也可以创建 User Namespace， 并且此用户在 Namespace 里
面可以被映射成 root， 且在 Namespace 内有 root 权限。
1. 3.6:
**Network Namespace**
Network Namespace 是用来隔离网络设备、 IP 地址端口 等网络械的 Namespace。 Network
Namespace 可以让每个容器拥有自己独立的（虚拟的）网络设备，而且容器内的应用可以绑定 到自己的端口，每个 Namespace 内的端口都不会互相冲突。在宿主机上搭建网桥后，就能很方 便地实现容器之间的通信，而且不同容器上的应用可以使用相同的端口 

1. 4.1:
**以下是对上面所有的Namescape的实现代码:**

```go
package main
import(
      "log"
      "os"
      "os/exec"
      "syscall"
)
func main(){
      cmd:=exec.Command("sh")
      cmd.SysProcAttr=&syscall.SysProcAttr{
             Cloneflags: syscall.CLONE_NEWUTS | syscall.CLONE_NEWIPC | syscall.CLONE_NEWPID | syscall.CLONE_NEWNS | syscall.CLONE_NEWUSER | syscall.CLONE_NEWNET //每一个syscall.CLONE_NEW参数都代表实现的一个NameScape
      }
      cmd.SysProcAttr.Credential=&syscall.Credential{Uid:uint32(1),Gid:uint32(1)}
      cmd.Stdin=os.Stdin
      cmd.Stderr=os.Stderr
      cmd.Stdout=os.Stdout
      if err:=cmd.Run();err!=nil{
           log.Fatal(err)
      os.Exit(-1)
}

```
