title: 自己动手写docker_1
date: '2019-11-25 17:08:10'
updated: '2019-11-25 17:08:10'
tags: [book, docker]
permalink: /articles/2019/11/25/1574672890033.html
---
![](https://img.hacpai.com/bing/20180813.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 容器与开发语言

1.1 *Docker:*
            Docker 是一个开源工具，它可以将你的应用打包成一个标准格式的镜像，并且以容器的 方式运行。 Docker 容器将一系列软件包装在一个**完整的文件系统**中，这个文件系统包含应用
程序运行所需要的一切：代码、运行时工具、系统工具、系统依赖，几乎有任何可以安装在服 务器上的东西。 这些策略保证了容器内应用程序运行环境的稳定性，不会被容器外的系统环境
所影响。
         **镜像可以把系统级依赖都打包成一个文件，所有的容器会共享一个 Kernel，因此在同一个 Kernel 下可以运行各种 Linux 发行版的容器。**


![null](https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1574681178393&di=3ce2952889df825559f41cc7c14d7d20&imgtype=0&src=http%3A%2F%2Fimg.linux.net.cn%2Fdata%2Fattachment%2Falbum%2F201712%2F11%2F223241y0thlaabla8ahh7z.jpg)

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190725075400401.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM3NjExMjcw,size_16,color_FFFFFF,t_70)

**Docker 容器具有以下 3 个特点。**
。轻量级：在同一台宿主机上的容器共享系统 Kernel, 这使得它们可以迅速启动而且占用
内存极少。 镜像是以分层文件系统构造的，这可以让它们共享相同的文件，使得磁盘使 用率和镜像下载速度得到提高。
。开放： Docker 容器基于开放标准，这使得 Docker 容器可以运行在主流 Linux 发行版和 Windows 操作系统上。
。安全：容器将各个应用程序隔离开来，这给所有的应用程序提供了一层额外的安全防护。

1.1.2 *容器和虚拟机比较:*
容器和虚拟机同样有着资源隔离和分配的优点，但是由于其架构的不同，容器比虚拟机更
加便携和高效。 
下面的两张图为容器和虚拟机的架构图比较:
**虚拟机:**
![image.png](https://img.hacpai.com/file/2019/11/image-bb5e2d50.png)
**容器:**

![image.png](https://img.hacpai.com/file/2019/11/image-89675143.png)
**容器优点:** 加速开发效率.将应用程序配置和所有依赖打包成一个镜像在容器中,避免因为环境不同的问题和配置问题.利用合作开发.以及上面说到的三个特点 等等.......
1.2:*Golang:*
不多解释了


