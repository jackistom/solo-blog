title: 自己动手写docker_3
date: '2019-11-28 17:50:21'
updated: '2019-11-28 17:50:50'
tags: [book, docker]
permalink: /articles/2019/11/28/1574934621212.html
---
1. 1:
**Linux Cgrous介绍:**
构建Linux容器的Namespace技术,它帮助进程隔离出自己单独的空间,但是Docker是怎么限制每个空间的大小的,保证它们不会互相争抢? 

1. 2:
**什么是Linux Cgroups(Linux Control Groups):**
Linux Cgroups提供了对一组进程及将来子进程的资源限制,控制和统计的能力.这些资源包括 CPU、内存、存储、网络等。 通过 Cgroups，可以方便地限制某个进 程的资源占用，并且可以实时地监控进程的监控和统计信息。

1.3:

